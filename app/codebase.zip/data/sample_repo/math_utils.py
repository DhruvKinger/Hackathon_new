# helper comment

def add(a, b):
    # inline decision
    if a == 0:
        return b
    return a + b


def max_of_three(a, b, c):
    if a > b and a > c:
        return a
    if b > c:
        return b
    return c


def classify(value):
    if value < 0:
        return "neg"
    elif value == 0:
        return "zero"
    return "pos"
