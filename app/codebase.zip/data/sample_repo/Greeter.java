public class Greeter {
    public String greet(String name) {
        if (name == null || name.isEmpty()) {
            return "Hello";
        }
        return "Hello, " + name;
    }

    public int score(int x) {
        int out = 0;
        for (int i = 0; i < x; i++) {
            out += i;
        }
        return out;
    }
}
