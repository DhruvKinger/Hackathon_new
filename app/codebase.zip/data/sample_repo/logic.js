function isEven(n) {
  return n % 2 === 0;
}

function classify(n) {
  if (n < 0) {
    return "negative";
  } else if (n === 0) {
    return "zero";
  }
  return "positive";
}

const choose = (a, b) => {
  if (a > b) {
    return a;
  }
  return b;
};
