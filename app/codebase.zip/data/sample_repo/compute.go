package main

func Fib(n int) int {
    if n <= 1 {
        return n
    }
    return Fib(n-1) + Fib(n-2)
}

func Sign(n int) string {
    if n < 0 {
        return "neg"
    }
    if n == 0 {
        return "zero"
    }
    return "pos"
}
